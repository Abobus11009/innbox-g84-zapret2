#!/bin/sh

BASE=/var/SaaS/zapret2
$BASE/add-rules.sh

exec $BASE/nfqws2 \
    --qnum=200 \
    --pidfile=/var/tmp/zapret2-nfqws.pid \
    --fwmark=0x40000000 \
    --lua-init=@$BASE/zapret-lib.lua \
    --lua-init=@$BASE/zapret-antidpi.lua \
    --filter-tcp=80,443 --in-range=-s1 \
      --lua-desync=oob:urp=0 \
    --new \
    --filter-udp=443 --filter-l7=quic --out-range=-d5 --in-range=-d3 \
      --payload=quic_initial \
      --lua-desync=fake:blob=fake_default_quic:repeats=6
