#!/bin/sh

LOCK=/var/tmp/zapret2-rules.lock
while ! mkdir $LOCK 2>/dev/null; do sleep 1; done
trap 'rmdir $LOCK 2>/dev/null' 0 1 2 15

while iptables -t mangle -D POSTROUTING -o nas1 -j Z2OUT 2>/dev/null; do :; done
while iptables -t mangle -D FORWARD -i nas1 -j Z2IN 2>/dev/null; do :; done
while iptables -t mangle -D INPUT -i nas1 -j Z2IN 2>/dev/null; do :; done
iptables -t mangle -F Z2OUT 2>/dev/null
iptables -t mangle -F Z2IN 2>/dev/null
iptables -t mangle -X Z2OUT 2>/dev/null
iptables -t mangle -X Z2IN 2>/dev/null

while ip6tables -t mangle -D POSTROUTING -o nas1 -j Z2OUT 2>/dev/null; do :; done
while ip6tables -t mangle -D FORWARD -i nas1 -j Z2IN 2>/dev/null; do :; done
while ip6tables -t mangle -D INPUT -i nas1 -j Z2IN 2>/dev/null; do :; done
ip6tables -t mangle -F Z2OUT 2>/dev/null
ip6tables -t mangle -F Z2IN 2>/dev/null
ip6tables -t mangle -X Z2OUT 2>/dev/null
ip6tables -t mangle -X Z2IN 2>/dev/null
