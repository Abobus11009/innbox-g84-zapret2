#!/bin/sh

LOCK=/var/tmp/zapret2-rules.lock
mkdir $LOCK 2>/dev/null || exit 0
trap 'rmdir $LOCK 2>/dev/null' 0 1 2 15

QNUM=200
WAN=nas1
MARK=0x40000000

iptables -t mangle -N Z2OUT 2>/dev/null
iptables -t mangle -N Z2IN 2>/dev/null
iptables -t mangle -C Z2OUT -p tcp -m multiport --dports 80,443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || iptables -t mangle -A Z2OUT -p tcp -m multiport --dports 80,443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass
iptables -t mangle -C Z2OUT -p udp --dport 443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || iptables -t mangle -A Z2OUT -p udp --dport 443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass
iptables -t mangle -C Z2IN -p tcp -m multiport --sports 80,443 --tcp-flags SYN,ACK SYN,ACK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || iptables -t mangle -A Z2IN -p tcp -m multiport --sports 80,443 --tcp-flags SYN,ACK SYN,ACK -j NFQUEUE --queue-num $QNUM --queue-bypass
iptables -t mangle -C Z2IN -p udp --sport 443 -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || iptables -t mangle -A Z2IN -p udp --sport 443 -j NFQUEUE --queue-num $QNUM --queue-bypass
iptables -t mangle -C POSTROUTING -o $WAN -j Z2OUT 2>/dev/null || iptables -t mangle -I POSTROUTING 1 -o $WAN -j Z2OUT
iptables -t mangle -C FORWARD -i $WAN -j Z2IN 2>/dev/null || iptables -t mangle -I FORWARD 1 -i $WAN -j Z2IN
iptables -t mangle -C INPUT -i $WAN -j Z2IN 2>/dev/null || iptables -t mangle -I INPUT 1 -i $WAN -j Z2IN

ip6tables -t mangle -N Z2OUT 2>/dev/null
ip6tables -t mangle -N Z2IN 2>/dev/null
ip6tables -t mangle -C Z2OUT -p tcp -m multiport --dports 80,443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || ip6tables -t mangle -A Z2OUT -p tcp -m multiport --dports 80,443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass
ip6tables -t mangle -C Z2OUT -p udp --dport 443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || ip6tables -t mangle -A Z2OUT -p udp --dport 443 -m mark ! --mark $MARK/$MARK -j NFQUEUE --queue-num $QNUM --queue-bypass
ip6tables -t mangle -C Z2IN -p tcp -m multiport --sports 80,443 --tcp-flags SYN,ACK SYN,ACK -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || ip6tables -t mangle -A Z2IN -p tcp -m multiport --sports 80,443 --tcp-flags SYN,ACK SYN,ACK -j NFQUEUE --queue-num $QNUM --queue-bypass
ip6tables -t mangle -C Z2IN -p udp --sport 443 -j NFQUEUE --queue-num $QNUM --queue-bypass 2>/dev/null || ip6tables -t mangle -A Z2IN -p udp --sport 443 -j NFQUEUE --queue-num $QNUM --queue-bypass
ip6tables -t mangle -C POSTROUTING -o $WAN -j Z2OUT 2>/dev/null || ip6tables -t mangle -I POSTROUTING 1 -o $WAN -j Z2OUT
ip6tables -t mangle -C FORWARD -i $WAN -j Z2IN 2>/dev/null || ip6tables -t mangle -I FORWARD 1 -i $WAN -j Z2IN
ip6tables -t mangle -C INPUT -i $WAN -j Z2IN 2>/dev/null || ip6tables -t mangle -I INPUT 1 -i $WAN -j Z2IN
