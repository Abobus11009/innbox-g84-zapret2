#!/bin/sh

appmgrcmd stop zapret2 2>/dev/null
appmgrcmd stop zapret2-rules 2>/dev/null
killall nfqws2 2>/dev/null
sleep 1
/var/SaaS/zapret2/del-rules.sh
rm -f /var/tmp/zapret2-nfqws.pid
