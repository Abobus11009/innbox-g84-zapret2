#!/bin/sh

echo "processes:"
ps | grep -E 'nfqws2|watch-rules.sh' | grep -v grep
echo "ipv4 counters:"
iptables -t mangle -L Z2OUT -n -v 2>/dev/null
iptables -t mangle -L Z2IN -n -v 2>/dev/null
echo "ipv6 counters:"
ip6tables -t mangle -L Z2OUT -n -v 2>/dev/null
ip6tables -t mangle -L Z2IN -n -v 2>/dev/null
