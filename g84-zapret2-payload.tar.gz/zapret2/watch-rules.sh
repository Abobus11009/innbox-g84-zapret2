#!/bin/sh

while true
do
    sleep 15
    /var/SaaS/zapret2/add-rules.sh
done
